# Inky Demo Skills and Agents

This package contains a compact demo set for an agentic platform in Word and Outlook. The workflows are host-neutral: the same skills are intended to work across supported hosts by selecting the available registered tools at runtime.

## Contents

```text
Inky.md
README.md
agents/
  shared_document_table_row_worker.md
  shared_contract_review_worker.md
  shared_researcher.md
skills/
  document-set-table-builder/SKILL.md
  contract-review-playbook/SKILL.md
  contract-review-playbook/References/contract-review-checklist.md
  complex-research-playbook/SKILL.md
  deadline-calculator/SKILL.md
  deadline-calculator/scripts/business-days.js
  skill-author/SKILL.md
```

## Design principles

- Skills orchestrate the workflow; shared agents perform focused analysis tasks.
- Tool use must stay within the registered tool names available to the current host.
- Factual extraction must be grounded in retrieved document text, metadata, Microsoft 365 content, or other registered source tools.
- State-changing calls, especially document comments or file writes, should be sequential and auditable.
- Final responses should state what was discovered, what was processed, what was skipped, and any verification counts.

## Skills

### `document-set-table-builder`

Builds a structured table from a collection of documents according to caller-defined columns and extraction criteria.

The skill must discover or retrieve the source documents, extract readable text or metadata, and then call `agent_shared_document_table_row_worker` once per processable source. The parent skill assembles only the rows returned by that agent and reports audit counts.

Typical outputs are Markdown tables, Word/Markdown reports, or an Excel workbook when the relevant output tool is available and requested.

### `contract-review-playbook`

Reviews a contract against the Markdown checklist in:

```text
skills/contract-review-playbook/References/contract-review-checklist.md
```

The skill delegates the substantive review to `agent_shared_contract_review_worker`, inserts findings as Word comments one at a time, and verifies the inserted comments at the end where comment-listing tools are available.

The checklist supports conditional rules, for example governing-law and dispute-resolution scenarios, data-processing issues, assignment/change-of-control provisions, liability caps, termination rights, and other contract-review topics.

### `complex-research-playbook`

Performs structured research using available web, local knowledge, Microsoft 365, and supplied-document sources. It is designed for multi-question research tasks and concise cited outputs.

### `deadline-calculator`

Calculates calendar-day and simple business-day deadlines deterministically. It must always state that the result is not a legal deadline calculation and does not account for court rules, statutory suspensions, service rules, or jurisdiction-specific holidays unless those assumptions are explicitly supplied.

### `skill-author`

Drafts, reviews, and revises Red Ink skills and agents using registered tools and host-neutral orchestration patterns.

## Shared agents

### `agent_shared_document_table_row_worker`

Extracts exactly one structured table row from one document/source using the caller's columns and criteria. It should return `Nicht ersichtlich` or `Not apparent` for unsupported cells, depending on the requested language, and must not invent legal citations or facts.

### `agent_shared_contract_review_worker`

Applies the contract-review checklist to extracted contract text and returns structured findings for the parent skill to comment into the document.

### `agent_shared_researcher`

Answers one focused research question using the available research and document tools, returning concise support for the parent skill.

## Demo example: Legal due diligence table

Example user prompt:

```text
Use the document-set-table-builder skill to prepare a legal due diligence table for the target company's material contracts. Create the columns: Document, Contract Type, Parties, Effective Date / Term, Governing Law and Forum, Assignment / Change of Control, Termination Rights, Liability Cap, Data Protection / Confidentiality, Material Red Flags, DD Follow-Up.
```

Expected workflow:

1. The skill loads and acts as the orchestrator.
2. The skill discovers the document collection and records the source list.
3. The skill extracts readable text or reliable metadata from each processable source.
4. The skill calls `agent_shared_document_table_row_worker` once per processable document, with `caller_skill: document-set-table-builder` in the task JSON.
5. The skill combines only the rows returned by the row-worker.
6. The final answer or output file includes the DD table and an audit line showing sources discovered, sources selected for processing, sources with text/metadata, row-worker calls attempted, row-worker calls successful, rows included, and skipped sources.

Concrete output shape:

| Document | Contract Type | Parties | Effective Date / Term | Governing Law and Forum | Assignment / Change of Control | Termination Rights | Liability Cap | Data Protection / Confidentiality | Material Red Flags | DD Follow-Up |
|---|---|---|---|---|---|---|---|---|---|---|
| Master Services Agreement - Alpha GmbH.pdf | Services agreement | TargetCo AG and Alpha GmbH | Effective 1 January 2022; initial term 24 months; automatic annual renewals unless terminated on notice. | Swiss law; ordinary courts of Zurich. | Assignment requires prior written consent; no express change-of-control trigger identified. | Ordinary termination with 90 days' notice before renewal; immediate termination for uncured material breach. | Aggregate liability capped at fees paid in the preceding 12 months; carve-outs for wilful misconduct and confidentiality breaches. | Mutual confidentiality clause; DPA or specific Art. 28 processor terms not apparent from the extracted text. | Potential data-processing gap if Alpha GmbH processes personal data without a separate DPA. | Confirm whether a DPA exists; check whether services involve personal data; review renewal/termination calendar. |
| Software Licence Agreement - BetaSoft Ltd.docx | Software licence / SaaS | TargetCo AG and BetaSoft Ltd. | Signed 15 March 2021; three-year term with renewal unless cancelled 60 days before expiry. | English law; ICC arbitration in Geneva. | Assignment prohibited without consent except to affiliates or in connection with merger/sale of substantially all assets. | Termination for non-payment, breach, or insolvency; customer convenience termination not apparent. | Vendor liability capped at annual fees; broad exclusion of indirect damages. | Confidentiality obligations included; security schedule referenced but not included in extracted materials. | Missing security schedule may be material for IT and privacy diligence. | Request referenced security schedule and any data-processing addendum; assess operational dependency and renewal date. |
| Distribution Agreement - Gamma SA.pdf | Distribution agreement | TargetCo AG and Gamma SA | Effective 1 July 2020; indefinite term after first year. | French law; courts of Paris. | No express change-of-control clause identified; assignment restrictions unclear. | Termination for convenience on six months' notice; immediate termination for serious breach. | No clear aggregate liability cap identified in the extracted text. | Confidentiality clause present; no personal-data clause identified. | Non-Swiss forum and absence of a clear liability cap may require legal review. | Confirm business criticality; obtain local-law review; assess exposure from uncapped liability. |

Audit line example:

```text
Audit: sources discovered: 3; sources selected for processing: 3; sources with text/metadata: 3; row-worker calls attempted: 3; row-worker calls successful: 3; rows included: 3; sources skipped: 0.
```

## Removed workflow

The former Outlook-specific attachment-table example and skill have been removed. Document collections should be handled through the host-neutral `document-set-table-builder` workflow instead of a dedicated attachment demo.
