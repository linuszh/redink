---
name: document-set-table-builder
description: Builds a structured table from a collection of documents according to caller-defined columns and extraction criteria. Works in Word and Outlook. This skill is the mandatory orchestrator for table-building requests and delegates every substantive row to the shared row-worker agent.
allowed-tools:
  - workspace_get
  - workspace_inventory
  - workspace_extract_text
  - workspace_extract_text_many
  - workspace_write
  - worddoc_get_active
  - worddoc_extract_text
  - word_extract_text
  - text_read
  - text_write
  - m365_search
  - m365_get_mail
  - m365_get_mail_thread
  - m365_get_file
  - agent_workspace_list
  - agent_workspace_read
  - agent_workspace_search
  - agent_workspace_find_files
  - agent_workspace_write
  - agent_shared_document_table_row_worker
  - create_excel_spreadsheet
  - js_run
  - skill_use
model: agentdefaultmodel
---

# Document Set Table Builder

Build a structured table from a collection of documents in Word or Outlook.

Use this skill for:

- due-diligence tables;
- annex / exhibit overviews;
- contract clause matrices;
- document inventories with legal or commercial extraction columns;
- issue lists from a folder, workspace, Microsoft 365 result, mail/thread, or supplied file paths.

Do not use or recreate a host-specific attachment-table workflow. Attachments may be source documents only when they are reachable through the registered document/source tools.

## Mandatory entry point

When the user asks for a table using the Table Builder, this skill must be loaded and executed before any row-worker agent is called.

Do not call `agent_shared_document_table_row_worker` directly from the top-level user request. The row-worker is an implementation detail of this skill. The row-worker may only be called after this skill has established:

1. the requested columns;
2. the source collection;
3. the extracted text or metadata for each source;
4. a per-source JSON task for the worker; and
5. audit counters for discovered, processed, skipped, worker calls, and included rows.

If the user explicitly names the Table-Builder-Skill and the current run has not yet loaded this skill, the next tool call must be `skill_document-set-table-builder` or `skill_use` for this skill. Do not satisfy the request by loading only the row-worker.

## Mandatory orchestration

This skill is an orchestrator. It must not perform substantive row extraction itself.

The required sequence is:

1. Identify the requested columns and extraction criteria.
2. Discover the document/source collection.
3. Extract or retrieve readable text or reliable metadata for each source.
4. For each processable source, call `agent_shared_document_table_row_worker` exactly once to produce exactly one structured row.
5. Combine only the agent-returned rows into the final table.
6. Validate column count, source coverage, and failures.
7. Return or save the table and report the audit counts.

`agent_shared_document_table_row_worker` is mandatory whenever at least one document/source is being analyzed. Do not bypass it by summarizing directly in the parent skill. Do not use `js_run` as a substitute for the row-worker.

## Inputs

The user may provide:

- a document collection, folder, workspace, email/thread, Microsoft 365 search scope, or file paths;
- columns or criteria;
- desired output format: Markdown table by default, optionally Word/Markdown report or Excel workbook;
- language.

If columns are not provided, choose defaults that fit the scenario.

### Default DD contract columns

Use these for due diligence or contract review tables when the user does not specify columns:

1. Datei
2. Dokumenttyp
3. Parteien
4. Datum / Laufzeit
5. Anwendbares Recht / Gerichtsstand
6. Kündigung
7. Change of Control / Abtretung
8. Haftung / Cap
9. Besondere Risiken
10. Kurzbewertung

### Default annex overview columns

1. Beilage
2. Datei / Quelle
3. Dokumenttyp
4. Datum
5. Parteien / Absender
6. Kurzinhalt
7. Relevanz
8. Offen / Auffällig

## Source discovery

Use the available tools appropriate for the current source location. Do not invent file names, document counts, summaries, or citations.

Discovery is mandatory and must be auditable before extraction. The parent skill must create a concrete source list before it calls the row-worker.

1. For workspace folders or visible local files, inspect the workspace first with `workspace_get` / `workspace_inventory` or `agent_workspace_find_files` / `agent_workspace_search`. Do this before `workspace_extract_text_many` unless the user provided an explicit file list.
2. Record every discovered candidate source with name/path, type, and inclusion decision.
3. Exclude non-document or unsupported files only with a short skip reason.
4. For multiple readable workspace files, prefer `workspace_extract_text_many` after the source list has been established. Otherwise read files individually with the appropriate workspace reader.
5. For saved `.docx` files, use `word_extract_text`.
6. For the active Word document, use `worddoc_get_active` and `worddoc_extract_text` when those tools are available.
7. For Microsoft 365 sources, use `m365_search`, `m365_get_file`, `m365_get_mail`, or `m365_get_mail_thread` as appropriate.
8. For plain text criteria or helper files, use `text_read` or workspace text tools.

If no source collection can be identified, ask for the document scope or report inability. Do not create a table from assumptions alone.

## Per-source row extraction

For every processable document/source, call `agent_shared_document_table_row_worker` with a JSON `task` containing:

```json
{
  "caller_skill": "document-set-table-builder",
  "orchestration_version": "v4",
  "source": {
    "id": "source id or path",
    "name": "display name",
    "type": "workspace-file | agent-workspace-file | docx-path | m365-file | m365-mail | m365-thread | text"
  },
  "columns": ["File", "One-Line-Summary", "Legal Citations"],
  "criteria": "Extraction criteria and scenario context",
  "language": "German or English",
  "audit": {
    "source_index": 1,
    "source_count": 4
  }
}
```

Pass already extracted source text in `context` where available. The worker must return one row with exactly the requested columns. The worker must use `Nicht ersichtlich` where the document does not answer a column and include short anchors or citation snippets only where supported by the source text.

The parent skill must use the row returned by the agent. It may normalize formatting, escape Markdown pipes, deduplicate duplicate sources, and assemble the table, but it must not add unsupported facts.

## Tool-call discipline

- Do not emit multiple state-changing output calls in one model turn.
- It is acceptable to make multiple read-only calls in one turn only if the tooling loop marks them as safely executable.
- When using `agent_shared_document_table_row_worker`, call it once per source and wait for the result before relying on the row.
- Use `js_run` only for mechanical assembly, sorting, deduplication, escaping Markdown, row-count validation, or table formatting. Never use `js_run` to fabricate factual rows, summaries, or legal citations.
- If a row-worker call fails, record the source as skipped or failed; do not silently replace the worker with parent-generated content.

## Required audit state

Maintain these counters during the run:

- `sources_discovered`
- `sources_selected_for_processing`
- `sources_with_text_or_metadata`
- `row_worker_calls_attempted`
- `row_worker_calls_successful`
- `rows_included`
- `sources_skipped`

Maintain a short skip list containing source name and reason.

Before final output, verify:

- a discovery step occurred, unless the user supplied an explicit file list;
- `sources_discovered == sources_selected_for_processing + sources_skipped`, unless duplicates were intentionally deduplicated and reported;
- `sources_selected_for_processing == row_worker_calls_attempted` for processable sources;
- `rows_included == row_worker_calls_successful` unless duplicates were intentionally deduplicated;
- no included row was created without a successful row-worker result;
- every skipped source has a short reason;
- the final table has exactly the requested columns in the requested order.

If the counters do not reconcile, say so explicitly and do not claim a complete table.

## Output

Return:

1. a concise description of the discovery scope and sources reviewed;
2. the table;
3. a short list of limitations or documents that could not be processed;
4. optional file output path if a report/workbook was created;
5. an audit line with: sources discovered, sources selected for processing, sources with text/metadata, row-worker calls attempted, row-worker calls successful, rows included, sources skipped.

The final response must include the audit line even when the table is also saved to a workspace file.

## Quality checks

Before final output:

- Confirm that `agent_shared_document_table_row_worker` was used for each included row.
- Validate that each row has the same columns in the same order.
- Deduplicate documents unless the user requested all versions.
- Flag extraction failures separately.
- State whether the table is based on full text, partial text, metadata, or email/thread text.
- State whether discovery used workspace inventory, explicit user-provided paths, Microsoft 365 search, or another source mechanism.
- Do not claim that files were analyzed unless their text or metadata was actually retrieved.
- Do not claim that the Table-Builder-Skill was used unless `skill_document-set-table-builder` or `skill_use` actually loaded this skill in the current run.
