---
name: word-template-drafting
description: Creates Word documents from templates stored in the skill references directory.
allowed-tools:
  - word_apply_template
  - word_save_as
  - word_extract_text
  - word_format
  - word_comment_add
  - workspace_get
  - workspace_inventory
  - memory_put
---

# Word Template Drafting Skill

Use this skill when the user wants to create a Word document from a reusable template.

## Workflow

1. Identify the template in `references/`.
2. Ask for missing placeholder values if necessary.
3. Use `word_apply_template` with:
   - `skill`: `word-template-drafting`
   - `template`: relative filename, e.g. `test-template.docx`
   - `output_name`: a clear filename ending in `.docx`
   - `substitutions`: JSON object matching placeholder names without braces

Example placeholders:
{ "title": "Project Note", "client": "Example AG", "date": "2026-05-14", "summary": "Short generated summary." }

4. Tell the user where the generated file was saved.

## Notes

- Do not write to the currently open document.
- Generated documents should go to the configured workspace or Desktop fallback.