# Template Instructions

The test template uses these placeholders:

- {{title}}
- {{client}}
- {{date}}
- {{summary}}

Use concise values. If values are missing, infer only if the user gave enough information; otherwise ask.