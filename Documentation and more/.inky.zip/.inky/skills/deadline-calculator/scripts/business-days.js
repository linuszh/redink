function parseISODate(s) {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}

function toISODate(d) {
  return d.toISOString().slice(0, 10);
}

function isWeekend(d) {
  const day = d.getUTCDay();
  return day === 0 || day === 6;
}

function addBusinessDays(startISO, days, includeStart = false) {
  let d = parseISODate(startISO);
  let remaining = days;

  if (includeStart && !isWeekend(d)) {
    remaining -= 1;
  }

  while (remaining > 0) {
    d.setUTCDate(d.getUTCDate() + 1);
    if (!isWeekend(d)) {
      remaining -= 1;
    }
  }

  return toISODate(d);
}

return {
  example: addBusinessDays("2026-05-14", 10, false),
  functions: ["parseISODate", "toISODate", "isWeekend", "addBusinessDays"]
};