---
name: deadline-calculator
description: Calculates calendar-day and simple business-day deadlines deterministically in Word and Outlook. Always warns that it is not legal deadline calculation.
allowed-tools:
  - js_run
  - text_read
model: agentdefaultmodel
---

# Deadline Calculator

Calculate dates, elapsed days, calendar-day offsets, and simple business-day offsets.

## Mandatory disclaimer

Every result must include this warning, in the user's language:

> This is a deterministic date calculation only and not a legal deadline calculation. It does not account for court rules, statutory suspensions, service rules, deemed receipt, time zones, local holidays, or jurisdiction-specific procedural rules unless those assumptions were explicitly provided.

In German:

> Dies ist nur eine deterministische Datumsberechnung und keine juristische Fristberechnung. Gerichtsregeln, gesetzliche Fristenstillstände, Zustellfiktionen, Zeitzonen, lokale Feiertage und jurisdiktionsspezifische Verfahrensregeln werden nicht berücksichtigt, sofern sie nicht ausdrücklich vorgegeben wurden.

## Inputs

- start date;
- number of days;
- calendar days or business days;
- whether the start date counts as day 0 or day 1;
- weekends excluded or included;
- holiday list, if any.

If assumptions are missing, use common defaults and state them clearly:

- start date is day 0;
- business days exclude Saturday and Sunday;
- no public holidays are excluded unless supplied.

## Tool usage

Use `js_run` for all date arithmetic. Use `scripts/business-days.js` as reference logic where accessible.

## Output

Return:

- calculated date;
- assumptions;
- day count basis;
- mandatory disclaimer.
