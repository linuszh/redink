---
name: deadline-calculator
description: Calculates deadlines, date offsets, business days, and timeline tables using deterministic JavaScript.
allowed-tools:
  - js_run
  - memory_put
---

# Deadline Calculator Skill

Use this skill when the user asks for date calculations, business-day offsets, limitation periods, schedules, or timeline tables.

## Rules

- Use `js_run` for all calculations.
- Do not calculate dates mentally.
- State assumptions explicitly:
  - jurisdiction/calendar if holidays are unknown,
  - whether start date is included,
  - whether weekends are excluded.
- If holidays are not provided, calculate weekdays only and say that public holidays were not considered.

## Suggested JavaScript approach

Use plain JavaScript `Date` objects in UTC-like `YYYY-MM-DD` form to avoid locale ambiguity.

If useful, inspect or adapt `scripts/business-days.js`.

## Output

Return:
- inputs used,
- assumptions,
- resulting date(s),
- a short table if multiple dates are computed.