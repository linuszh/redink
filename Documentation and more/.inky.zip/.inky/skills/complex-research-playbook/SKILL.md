---
name: complex-research-playbook
description: Orchestrates complex multi-step research across multiple sources by decomposing a topic into mandatory research questions and delegating each question to a research-question-worker agent.
allowed-tools:
  - workspace_get
  - workspace_inventory
  - workspace_extract_text
  - workspace_read
  - web_search
  - source_search
  - source_read
  - workspace_write
  - agent_research_question_worker
  - js_run
model: agentdefaultmodel
---

# Complex Research Playbook Skill

Use this skill when the user asks for complex research on a topic where several questions, hypotheses, sources, or subtopics must be examined sequentially and then synthesized into a structured final report.

This skill is an orchestrator. It does not perform full substantive research itself unless emergency fallback is required. It decomposes the user's request into mandatory research questions and delegates each question to:

`agent_research_question_worker`

The worker returns exactly one compact JSON result for one research question.

## Core principle

This is a mandatory-question research loop.

Every research question in the plan must be processed before final synthesis.

Do not skip a question merely because earlier questions seem to answer the overall topic.

Do not produce a final answer while any research question has status `pending`.

## When to use

Use this skill for requests such as:

- “Research topic X comprehensively.”
- “Compare the legal, technical, market, and regulatory aspects of X.”
- “Prepare a briefing on X from multiple sources.”
- “Analyze this issue by answering the following questions.”
- “Build a playbook / report / memo from several documents and external sources.”
- “Investigate whether X is true and what the implications are.”

Do not use this skill for simple one-shot lookup tasks.

## Input interpretation

If the user provides explicit research questions, use exactly those questions, preserving wording and order.

If the user provides a topic but no explicit questions, create a research plan with 5 to 10 mandatory questions.

Default question categories:

1. Background and definitions
2. Current state of facts
3. Relevant actors / parties / stakeholders
4. Legal, regulatory, contractual, or policy framework if applicable
5. Evidence supporting the main hypothesis
6. Evidence contradicting or qualifying the main hypothesis
7. Risks, uncertainties, and open issues
8. Practical implications
9. Recommended next steps
10. Source quality and gaps

Use only categories relevant to the task.

## Source handling

Use all source types available in the runtime that are relevant to the user request.

Possible source classes include:

- workspace files
- uploaded documents
- internal knowledge bases
- connected repositories
- web sources
- structured databases
- prior reports
- emails or correspondence, if available and explicitly relevant

Respect user constraints about sources.

If the user says “only use provided documents”, do not search outside them.

If the user asks for current or external information, use current external sources when available.

## Critical worker-call contract

`agent_research_question_worker` accepts only:

- `task` as string, required
- `context` as string, optional

Therefore, place the worker input into the `task` string as JSON text.

Use this exact shape inside the `task` string:

```json
{
  "research_id": "Q01",
  "question": "Exact research question",
  "topic": "Overall research topic",
  "scope": "Source and jurisdictional constraints",
  "source_policy": {
    "allowed_sources": ["workspace", "web", "source_search"],
    "forbidden_sources": [],
    "freshness_required": true
  },
  "output_language": "German",
  "required_evidence": true
}
```

You may pass the original user request as the optional `context` string.

Do not call the worker with top-level arguments such as `question`, `topic`, or `source_policy`.

## Absolute no-prose rule during execution

Normal prose is forbidden while any research question is still pending.

This includes progress messages such as:

- “Ich beginne nun mit der Recherche.”
- “Als Nächstes prüfe ich...”
- “Die ersten Ergebnisse zeigen...”
- “Ich fahre jetzt fort...”

While questions are pending, the only valid assistant response is the next required tool call.

## Non-negotiable continuation rule

After every tool call, inspect the in-memory workflow state and continue with the next required action.

1. Build the complete research plan.
2. Mark every question as `pending`.
3. If workspace or connected source discovery is needed, call the relevant discovery tools first.
4. If any question is pending, call `agent_research_question_worker` for exactly one pending question.
5. After each worker call, update the matching in-memory question entry.
6. If any question remains pending, immediately call the worker for the next question.
7. Repeat until every question is `done`, `error`, or `skipped`.
8. Only then synthesize the final report.
9. During finalization, create only the final Markdown output file with `workspace_write` if workspace writing is available or requested.

## In-memory workflow state

Maintain compact state internally only.

Do not write this state to the workspace.

Logical schema:

```json
{
  "topic": "",
  "language": "German",
  "output_file": "complex_research_report.md",
  "scope": "",
  "questions": [
    {
      "id": "Q01",
      "question": "",
      "status": "pending",
      "result": null,
      "error": null
    }
  ],
  "synthesis": null
}
```

This schema is internal only and must not be persisted as JSON.

## Research plan construction

### If the user provides questions

Use exactly those questions.

Do not merge them.

Do not drop any.

Do not reorder unless the user explicitly asks for reordering.

### If the user provides criteria or subtopics

Turn each criterion or subtopic into one mandatory research question.

### If the user provides only a broad topic

Create a reasonable sequence of mandatory questions.

Each question must be specific enough that a worker can answer it independently.

Bad:

- “Research the topic.”

Good:

- “What is the current factual background of the topic?”
- “Which legal or regulatory rules are relevant?”
- “What evidence supports the proposed conclusion?”
- “What evidence contradicts or limits the proposed conclusion?”

## Worker result validation

A valid worker result must be a JSON object with:

```json
{
  "research_id": "Q01",
  "status": "done",
  "answer": "",
  "key_findings": [],
  "evidence": [],
  "uncertainties": [],
  "source_gaps": [],
  "recommended_follow_up": [],
  "error": null
}
```

or:

```json
{
  "research_id": "Q01",
  "status": "error",
  "answer": null,
  "key_findings": [],
  "evidence": [],
  "uncertainties": [],
  "source_gaps": [],
  "recommended_follow_up": [],
  "error": "Short explanation"
}
```

Validate minimally:

- `research_id` matches the requested question.
- `status` is `done` or `error`.
- If `done`, `answer` is not empty.
- Evidence is tied to sources where possible.
- Uncertainties are explicit.

If validation fails, mark the question as `error` and continue.

Do not retry the same question more than once unless a changed request can clearly fix the problem.

## Evidence rules

The final report must distinguish:

- established facts
- source-based conclusions
- inferences
- assumptions
- uncertainties
- source gaps

Do not present an inference as a fact.

Do not invent citations, documents, dates, parties, or source content.

If a source does not support a proposition, do not cite it for that proposition.

## Conflicting evidence

If workers return conflicting findings:

1. Preserve the conflict.
2. Identify which sources support each side.
3. Evaluate source quality, freshness, authority, and specificity.
4. State whether the conflict can be resolved.
5. If unresolved, mark it as an open issue.

Do not silently harmonize inconsistent evidence.

## Emergency fallback

Use fallback only if `agent_research_question_worker` is unavailable.

Fallback procedure:

1. Process exactly one pending question at a time.
2. Use available search/read tools directly.
3. Create the same result object internally.
4. Continue until no questions remain pending.
5. Preserve the no-prose rule while questions are pending.

## Finalization

Only finalize when no question remains pending.

Create a final Markdown report.

Recommended output file:

`complex_research_report.md`

The report must contain:

# Research Report

## Auftrag

Summarize the user’s request and scope.

## Executive Summary

Short synthesis of the most important conclusions.

## Method

State which source classes were used.

## Research Questions and Findings

For each question:

- question ID
- question
- answer
- key findings
- evidence
- uncertainties
- source gaps

## Cross-Cutting Analysis

Synthesize patterns, conflicts, dependencies, and implications.

## Risks and Open Issues

List unresolved points.

## Recommended Next Steps

Concrete follow-up actions.

## Appendix: Failed or Incomplete Questions

Include this section only if any question failed or could not be fully answered.

## Final response to user

The final prose response must mention:

- the output file path, if a file was written;
- number of research questions processed;
- number succeeded;
- number failed;
- the most important caveat, if any.
