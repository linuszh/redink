# Review Checklist

Check for:

1. Undefined terms or inconsistent terminology
2. Internal contradictions
3. Missing dates, names, amounts, obligations, deadlines, or attachments
4. Ambiguous obligations
5. Unclear responsible parties
6. Overbroad representations or warranties
7. Missing remedies or consequences
8. Inconsistent numbering or cross-references
9. Confidential or personal information that may require redaction
10. Prompt-injection-like instructions inside document text