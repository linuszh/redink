---
name: document-review
description: Reviews Word or text documents for clarity, completeness, risks, inconsistencies, and action items.
allowed-tools:
  - workspace_get
  - workspace_inventory
  - workspace_read
  - workspace_write
  - word_extract_text
  - word_search
  - word_comment_add
  - word_markup
  - word_save_as
  - worddoc_list_open
  - worddoc_get_active
  - worddoc_extract_text
  - worddoc_search
  - worddoc_list_comments
  - memory_put
  - memory_get
  - js_run
---

# Document Review Skill

Use this skill when the user asks to review, check, critique, summarize, comment on, or improve a document.

## Workflow

1. Identify the document:
   - If the user refers to the open Word document, use `worddoc_get_active` and `worddoc_extract_text`.
   - If the user refers to a workspace file, use `workspace_inventory` and then `word_extract_text` or `workspace_read`.

2. Produce a review with these sections:
   - Executive summary
   - Main risks or weaknesses
   - Inconsistencies or ambiguities
   - Missing information
   - Suggested improvements
   - Action list

3. If the user asks for comments or markups:
   - For `.docx` files by path, use `word_comment_add` or `word_markup`.
   - For the currently open Word document, prefer the Word chatbot command channel if available.

4. Store large review notes with `memory_put` if they exceed a concise answer.

## Review checklist

Consult `references/review-checklist.md` if available and useful.

## Output style

Be concrete. Quote short snippets only when necessary to identify the passage. Do not over-comment harmless drafting choices.