# Contract Review Checklist

This Markdown playbook defines the default review criteria for `contract-review-playbook`. The reviewer must apply both the general criteria and the conditional if/then rules.

## Comment style

Use short Word comments in this form:

```text
[Severity] Issue. Why it matters. Suggested action.
```

Example:

```text
[Medium] The termination clause allows termination only for cause and has no convenience termination. Consider whether a no-fault termination right is required for this transaction.
```

## Severity guide

- **High:** likely deal blocker, unenforceability risk, major liability exposure, missing core clause, or rule failure with material consequences.
- **Medium:** negotiable but important risk, ambiguity, operational gap, or missing fallback.
- **Low:** drafting improvement, clarification, consistency issue.
- **Info:** observation, neutral note, or point for client confirmation.

## General contract criteria

### CR-01 Parties and capacity

Check whether all parties are clearly identified, including legal form, registered office/address, and signature capacity if visible.

Comment if:

- a party is ambiguous;
- signature blocks do not match the party names;
- authority or capacity appears unclear.

### CR-02 Scope / subject matter

Check whether obligations, deliverables, services, or transaction object are sufficiently defined.

Comment if scope is vague, internally inconsistent, or dependent on missing schedules.

### CR-03 Price, payment, taxes

Check consideration, payment deadlines, invoicing, VAT/taxes, currency, late payment, and set-off.

Comment if key economic terms are missing or inconsistent.

### CR-04 Term and termination

Check effective date, initial term, renewal, ordinary termination, termination for cause, cure periods, and consequences of termination.

Comment if:

- no clear start date or term exists;
- there is no practical termination right;
- cure periods are missing for remediable breaches;
- post-termination obligations are unclear.

### CR-05 Liability and indemnity

Check limitation of liability, exclusions, indirect/consequential damages, indemnities, carve-outs, and insurance.

Comment if:

- liability is unlimited without policy reason;
- cap is missing or not tied to fees/transaction value;
- carve-outs are too broad or one-sided;
- indemnity duplicates or conflicts with liability regime.

### CR-06 Confidentiality

Check confidentiality scope, exceptions, duration, permitted disclosures, return/destruction, and remedies.

Comment if confidentiality is absent, overly broad, unlimited without justification, or lacks standard exceptions.

### CR-07 IP / ownership / usage rights

Check ownership of pre-existing IP, created work product, licenses, restrictions, and open-source or third-party rights.

Comment if ownership or usage rights are unclear.

### CR-08 Data protection and security

Check whether personal data processing, processor/controller roles, technical and organizational measures, sub-processors, audit rights, and cross-border transfers are addressed.

Comment if data processing appears likely but no data protection provisions are present.

### CR-09 Assignment, change of control, subcontracting

Check assignment restrictions, group transfers, change of control, subcontracting rights, and consent requirements.

Comment if transfer restrictions could block the contemplated transaction or operation.

### CR-10 Governing law and dispute resolution

Check governing law, courts, arbitration, venue, language of proceedings, and interim relief.

Apply the conditional rules below.

### CR-11 Compliance / sanctions / anti-bribery

Check whether compliance obligations fit the transaction and parties.

Comment if compliance risks appear relevant but no clause is present.

### CR-12 Entire agreement, hierarchy, amendments, notices

Check integration clause, order of precedence, amendment form, notice mechanics, and electronic communications.

Comment if schedules conflict with the main agreement or hierarchy is missing.

## Conditional if/then rules

### IF Swiss law THEN Zurich forum

If the contract is governed by Swiss law:

- Check whether the dispute resolution clause provides for courts in Zurich, Switzerland, unless the user has supplied another desired forum.
- If no court is specified, comment with **Medium** severity.
- If a non-Swiss or non-Zurich court is specified without an apparent reason, comment with **Medium** or **High** severity depending on transaction importance.
- If arbitration is used instead of courts, do not automatically reject it; check whether the arbitration clause is complete and commercially intended.

### IF non-Swiss law THEN arbitration check

If the contract is not governed by Swiss law, or if governing law is absent:

- Check whether there is an arbitration clause under ICC or an equivalent recognized institution.
- If no arbitration clause exists and cross-border enforcement may matter, comment with **Medium** severity.
- If an ICC clause exists, check seat, number of arbitrators, language, institution/rules, and interim relief.
- If arbitration details are incomplete, comment with **Medium** severity.

### IF personal data THEN DPA requirements

If the contract involves personal data, employee data, customer data, cloud services, IT services, marketing data, analytics, or support access:

- Check controller/processor roles.
- Check data processing agreement or equivalent provisions.
- Check sub-processor rules.
- Check cross-border transfer mechanism if data may leave Switzerland/EEA/UK or another relevant protected jurisdiction.
- Comment with **High** severity if processing is central and no DPA exists; otherwise **Medium**.

### IF SaaS/cloud/IT services THEN service levels and security

If the contract concerns SaaS, cloud, hosting, IT outsourcing, support, or managed services:

- Check availability/service levels, maintenance windows, support times, security measures, incident notification, backups, business continuity, and audit/reporting.
- Comment if service levels or security obligations are missing or vague.

### IF M&A / transaction DD THEN consent and termination focus

If the contract is reviewed for a transaction or due diligence:

- Check change-of-control, assignment, termination triggered by transaction, exclusivity, non-compete, most-favoured customer, and key-person clauses.
- Comment if consent may be required or termination can be triggered by the transaction.

### IF employment / contractor context THEN worker classification

If the contract concerns an individual service provider, consultant, freelancer, or contractor:

- Check independence, no authority to bind, tax/social security responsibility, equipment, exclusivity, working time control, and substitution rights.
- Comment if the agreement resembles employment despite contractor wording.

### IF consumer/customer standard terms THEN unusual clauses

If the contract appears to be standard terms with customers or consumers:

- Check unusual, one-sided, or surprising clauses.
- Check limitation of liability, unilateral changes, termination, automatic renewal, and governing law/forum.
- Comment if enforceability or transparency concerns arise.

## Missing information rule

If a criterion cannot be assessed because text, schedules, attachments, or definitions are missing, create an `Info` or `Low` finding unless the missing item is central to the transaction, in which case use `Medium`.

## No-finding rule

Do not comment just to say that a clause is acceptable. Mention acceptable major points only in the final summary if useful.
