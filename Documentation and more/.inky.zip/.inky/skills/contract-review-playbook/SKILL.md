---
name: contract-review-playbook
description: Orchestrates a mandatory criterion-by-criterion contract review and uses a comment tool to annotate relevant text passages with review comments.
allowed-tools:
  - workspace_get
  - workspace_inventory
  - workspace_extract_text
  - workspace_read
  - contract_get_text
  - contract_find_sections
  - contract_add_comment
  - workspace_write
  - agent_contract_criterion_reviewer
  - js_run
model: agentdefaultmodel
---

# Contract Review Playbook Skill

Use this skill when the user asks to review a contract, agreement, terms, policy, addendum, annex, or other legal document against multiple mandatory criteria.

Every criterion must be checked.

Where relevant, the skill must annotate the contract text using the available comment tool.

This skill is the orchestrator only.

It delegates each individual review criterion to:

`agent_contract_criterion_reviewer`

The criterion reviewer returns exactly one compact JSON object for one criterion.

## Core principle

This is a mandatory-criteria review loop.

Every criterion must end in one of these statuses:

- `compliant`
- `issue`
- `missing`
- `unclear`
- `not_applicable`
- `error`

Do not finalize while any criterion remains `pending`.

Do not silently skip criteria.

Do not merge criteria unless the user explicitly asks for that.

## When to use

Use this skill for requests such as:

- “Review this contract against these points.”
- “Check whether all required clauses are present.”
- “Comment on problematic clauses.”
- “Perform a legal checklist review.”
- “Review the agreement for risks.”
- “Check the contract against our playbook.”
- “Annotate the contract where changes are needed.”

## Contract source selection

If the user specifies exact contract files, use exactly those files.

If the user specifies one active document, review that document.

If several possible contracts exist and the user has not specified one, select the most likely contract document based on file name, document type, and user context.

If selection is ambiguous, proceed with the most likely document and record the ambiguity in the final report.

Do not stop for clarification unless no usable contract can be identified.

## Criteria handling

If the user provides explicit criteria, use exactly those criteria, preserving wording and order.

If the user provides a checklist file, extract the checklist and use each checklist item as a criterion.

If the user asks for a general contract review without criteria, create a default review checklist.

Default criteria:

1. Parties and authority
2. Scope of services / deliverables
3. Price, payment terms, taxes, and invoicing
4. Term, renewal, and termination
5. Warranties and representations
6. Liability limitations and exclusions
7. Indemnities
8. Confidentiality
9. Data protection and security
10. Intellectual property and usage rights
11. Compliance with law and regulatory obligations
12. Assignment, subcontracting, and change of control
13. Governing law and dispute resolution
14. Notices
15. Entire agreement, amendments, order of precedence
16. Missing definitions, inconsistencies, and drafting issues

Use only criteria relevant to the contract type and user request.

## Critical worker-call contract

`agent_contract_criterion_reviewer` accepts only:

- `task` as string, required
- `context` as string, optional

Place the worker input into the `task` string as JSON text.

Use this exact shape inside the `task` string:

```json
{
  "review_id": "C01",
  "contract": {
    "path": "workspace-relative/path.ext",
    "name": "contract.ext"
  },
  "criterion": {
    "title": "Criterion title",
    "question": "Exact criterion to check",
    "severity_guidance": "How to classify issues if applicable"
  },
  "comment_policy": {
    "add_comments": true,
    "comment_tool": "contract_add_comment",
    "comment_required_for_statuses": ["issue", "missing", "unclear"],
    "comment_style": "concise, practical, in German"
  },
  "output_language": "German"
}
```

You may pass the original user request and any global review instructions as the optional `context` string.

Do not call the worker with top-level arguments such as `contract`, `criterion`, or `comment_policy`.

## Absolute no-prose rule during execution

Normal prose is forbidden while any criterion is pending.

This includes progress messages such as:

- “Ich prüfe jetzt die Haftung.”
- “Die ersten Kriterien sind erledigt.”
- “Als Nächstes kommentiere ich...”
- “Ich fahre fort...”

While criteria are pending, the only valid assistant response is the next required tool call.

## In-memory workflow state

Maintain compact state internally only.

Do not write this state to the workspace.

Logical schema:

```json
{
  "contract": {
    "path": "",
    "name": ""
  },
  "language": "German",
  "output_file": "contract_review_report.md",
  "criteria": [
    {
      "id": "C01",
      "title": "",
      "question": "",
      "status": "pending",
      "result": null,
      "error": null
    }
  ],
  "comments_added": []
}
```

This schema documents internal state only and must not be persisted as JSON.

## Workflow

### Phase 1 — Initialize

1. Confirm workspace or contract source access if needed.
2. Identify the contract document.
3. Determine the mandatory review criteria.
4. Build the in-memory workflow state.
5. Set every criterion to `pending`.
6. Do not create an intermediate JSON state file.
7. Do not produce prose.
8. Immediately continue with Phase 2.

### Phase 2 — Process criteria via reviewer agent

For each pending criterion:

1. Select exactly one pending criterion.
2. Call `agent_contract_criterion_reviewer`.
3. Put the worker input JSON into the worker tool’s `task` string.
4. Pass the original user request as optional `context`.
5. Validate the worker result.
6. Update the matching criterion entry.
7. Store any comment references returned by the worker.
8. If any criterion remains pending, immediately call the reviewer for the next criterion.

## Worker result validation

A valid worker result must be a JSON object with:

```json
{
  "review_id": "C01",
  "criterion_title": "Criterion title",
  "status": "compliant|issue|missing|unclear|not_applicable",
  "severity": "high|medium|low|none",
  "finding": "",
  "evidence": [
    {
      "section": "",
      "text_anchor": "",
      "summary": ""
    }
  ],
  "comments": [
    {
      "comment_id": "",
      "section": "",
      "text_anchor": "",
      "comment": ""
    }
  ],
  "recommended_action": "",
  "error": null
}
```

or:

```json
{
  "review_id": "C01",
  "criterion_title": "Criterion title",
  "status": "error",
  "severity": "none",
  "finding": null,
  "evidence": [],
  "comments": [],
  "recommended_action": null,
  "error": "Short explanation"
}
```

Validation checks:

- `review_id` matches the requested criterion.
- `status` is one of the allowed statuses.
- If status is `issue`, `missing`, or `unclear`, `recommended_action` must not be empty.
- If comments were required, at least one comment should be present unless no text anchor could be located.
- If no text anchor could be located, this must be stated in `finding` or `error`.

## Commenting rules

Use comments for:

- problematic clauses
- missing clauses where a related section exists
- unclear wording
- contradictions
- unacceptable risk allocation
- missing definitions
- drafting errors with legal or practical effect

Do not comment every neutral or compliant clause.

A comment must be:

- attached to a specific passage whenever possible;
- concise;
- actionable;
- written in the requested language;
- understandable without the final report.

For missing clauses:

- Comment near the most relevant existing section.
- If no relevant section exists, the worker should return the issue without a comment and explain that no anchor was found.

## Severity rules

Use:

- `high`: material legal, commercial, regulatory, or operational risk; missing key clause; unacceptable liability or compliance exposure.
- `medium`: meaningful issue requiring negotiation or clarification.
- `low`: drafting issue, minor ambiguity, or improvement suggestion.
- `none`: compliant or not applicable.

## Status rules

- `compliant`: criterion is sufficiently addressed.
- `issue`: clause exists but is problematic, incomplete, risky, inconsistent, or unfavorable.
- `missing`: expected clause or concept is not found.
- `unclear`: text is ambiguous or evidence is insufficient.
- `not_applicable`: criterion is not relevant to this contract type or scope.
- `error`: criterion could not be reviewed due to tool/input failure.

## Emergency fallback

Use fallback only if `agent_contract_criterion_reviewer` is unavailable.

Fallback procedure:

1. Extract/read the contract text once if possible.
2. Process exactly one criterion at a time.
3. Use `contract_find_sections` to locate relevant sections where available.
4. Use `contract_add_comment` for issues, missing items with anchors, and unclear clauses.
5. Create the same result object internally.
6. Continue until no criteria remain pending.
7. Preserve the no-prose rule while criteria are pending.

## No incomplete review rule

Finalization is forbidden if any criterion remains pending.

A final review report must never state that the contract was fully reviewed unless every criterion reached a terminal status.

## Finalization

Only finalize when no criterion remains pending.

Create a final Markdown report.

Recommended output file:

`contract_review_report.md`

The report must contain:

# Contract Review Report

## Auftrag und Dokument

- contract name/path
- review scope
- criteria source

## Executive Summary

- overall risk level
- most important issues
- number of comments added

## Review Matrix

Markdown table with columns:

- ID
- Criterion
- Status
- Severity
- Finding
- Evidence
- Comments
- Recommended Action

## High Priority Issues

List all high-severity findings.

## Missing / Unclear Items

List all `missing` and `unclear` findings.

## Comments Added

List comment references returned by the workers.

## Failed Criteria

Include only if any criterion has status `error`.

## Limitations

State source gaps, unreadable files, ambiguous document selection, or criteria that could not be fully assessed.

## Final response to user

The final prose response must mention:

- reviewed contract path/name;
- number of criteria checked;
- number of issues;
- number of missing items;
- number of comments added;
- output file path, if written.
