---
name: skill-author
description: Helps design, improve, and validate Red Ink / Claude-compatible skills and agents.
allowed-tools:
  - workspace_get
  - workspace_inventory
  - workspace_read
  - workspace_write
  - text_read
  - text_write
  - text_search
  - memory_put
---

# Skill Author Skill

Use this skill when the user wants to create, improve, test, or document skills or agents.

## Safety

Only edit skill files when skill-author mode is active and the user explicitly asks for edits.

## Skill file guidance

A good `SKILL.md` should contain:

1. YAML frontmatter:
   - `name`
   - `description`
   - `allowed-tools`
   - optional `network`
   - optional `timeout`

2. Clear workflow:
   - when to use the skill,
   - what tools to call,
   - what output format to produce,
   - what not to do.

3. Minimal references:
   - Put longer checklists in `references/`.
   - Put deterministic scripts in `scripts/`.

## Agent file guidance

An agent should be self-contained. It must not rely on the parent conversation unless the parent passes context explicitly.

## Output

When editing a skill, summarize:
- file changed,
- reason,
- important instructions added or removed,
- next test to run.