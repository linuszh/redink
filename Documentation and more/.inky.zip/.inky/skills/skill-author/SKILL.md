---
name: skill-author
description: Drafts, reviews, and revises Red Ink skills and agents using only registered host tools and consistent orchestration contracts.
allowed-tools:
  - text_read
  - text_write
  - text_search
  - workspace_read
  - workspace_write
  - agent_workspace_read
  - agent_workspace_write
  - tool_loader
  - js_run
model: agentdefaultmodel
---

# Skill Author

Use this skill to create or revise Red Ink skills and agents.

## Goals

- Keep skill sets small, demonstrable, and host-aware.
- Use only registered tool names.
- Separate user-facing skills from focused delegated agents.
- Include clear input, workflow, tool usage, output, and limitation sections.
- Remove stale or duplicate skills instead of accumulating overlapping workflows.

## Review checklist

When reviewing a skill or agent:

1. Identify intended host: Word, Outlook, or both.
2. Check every tool name against the registered tool list.
3. Remove tools that belong only to the other host unless the skill has explicit host branching.
4. Prefer shared tools for shared workflows.
5. Avoid one-off agent proliferation; reuse shared workers where possible.
6. Ensure write/comment tools are only used after inspection.
7. Include safe failure behavior.
8. Include deterministic validation with `js_run` for JSON, tables, dates, sorting, and deduplication.

## Output format

Return revised Markdown files or a concise patch plan. If writing files, state exact paths created or changed.
