# Skill Format

Recommended frontmatter:

---
name: short-kebab-name
description: One-sentence trigger description.
allowed-tools:
  - tool_name
network: false
timeout: 30
---

Recommended body sections:

# Skill Name

## When to use

## Workflow

## Tool usage

## Output format

## Safety / constraints