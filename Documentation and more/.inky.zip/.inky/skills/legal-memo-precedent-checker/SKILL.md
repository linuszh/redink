---
name: legal-memo-precedent-checker
description: Reviews a legal memo or other legal-analysis Word document for correctness, currentness, authority support, negative treatment, and missing material legal points, then adds concise Word comments at relevant source-document anchors. Works in Word and Outlook when a comment-capable Word document is available.
allowed-tools:
  - selected_online_sources
  - text_read
  - text_search
  - word_extract_text
  - word_search
  - word_comment_add
  - word_comment_list
  - m365_get_file
  - agent_workspace_read
  - workspace_extract_text
  - workspace_read
  - js_run
  - skill_use
  - agent_legal-issue-precedent-checker
model: agentdefaultmodel
---

# Legal Memo Precedent Checker

Review a legal memo, brief, note, or other legal-analysis document for whether its legal statements are correct, current, sufficiently supported by authority, and complete as to all material issues raised by the document. Add useful findings as Word comments in the source document when a comment-capable Word document is available.

This skill is for legal research quality control and precedent/fact checking. It is not a final legal opinion and must not replace responsible lawyer review.

## Non-negotiable tool names

The delegated research tool is named exactly:

`agent_legal-issue-precedent-checker`

Do not call `agent_legal_issue_precedent_checker`.
Do not call `agent_shared_researcher` for this skill.
Do not perform substantive legal research in the parent skill except to recover from a minor formatting failure in an already completed agent result. If the subagent is unavailable or returns a configuration error, stop and report the configuration problem.

## Core objective

The skill must not review the document only at a high level. It must walk through the document step by step and isolate every discrete legal topic, legal assertion, precedent proposition, statutory proposition, regulatory proposition, procedural-rule proposition, deadline, test, burden, standard, remedy, exception, limitation, and confined complex of issues.

A long document must be handled by batching, not by truncating the review. There is no fixed maximum number of review units. Continue until all material review units have been processed or until the host run limit is reached. If the run limit is reached, report exactly which units remain unprocessed.

Examples of review units:

- a single legal proposition, e.g. "Swiss courts require X";
- a citation-based precedent statement, e.g. "Case A held Y";
- a statutory or regulatory proposition;
- an elements/test statement;
- an exception, limitation, burden, standard of review, deadline, or remedy statement;
- a confined paragraph-level issue cluster where several sentences make one legal point;
- an omission risk where the memo discusses a topic but omits an obviously material element, contrary authority, exception, or current-law development.

## Supported targets

### Word host

- Saved `.docx` file path: use `word_extract_text`, `word_search`, and `word_comment_add`.
- If a host-specific active-document tool is not exposed, do not invent one; ask for or use the saved `.docx` path that is available in the workspace/context.

### Outlook host

- Saved `.docx` file path: use `word_extract_text`, `word_search`, and `word_comment_add`.
- M365 file or agent workspace file: retrieve text using `m365_get_file`, `agent_workspace_read`, `workspace_extract_text`, or `workspace_read` as appropriate.
- If a comment-capable `.docx` copy/path is available, add comments with `word_comment_add`.
- If only non-commentable text is available, provide a findings report and clearly state that Word comments were not inserted.

## Mandatory workflow

1. Identify the target document and whether Word comments can be inserted.
2. Extract the document text before making any changes.
3. Build a document map:
   - title, headings, sections, paragraphs, footnotes/endnotes if visible in extracted text;
   - citations, statutes, regulations, authorities, defined legal terms;
   - jurisdiction, forum, governing law, date of document, and stated research cut-off date if present.
4. Segment the whole memo into review units. Each unit must have:
   - `unit_id`;
   - `anchor_text`;
   - `section_heading`;
   - `issue_type`;
   - `jurisdiction_or_forum`;
   - `proposition_or_issue`;
   - `authorities_mentioned`;
   - `document_context`;
   - `why_this_unit_requires_checking`.
5. Use `js_run` only for deterministic cleanup, deduplication, ordering, and JSON validation of the unit list. Do not use `js_run` to inspect the host UI or search for hidden prompt data.
6. Ensure coverage: every material legal statement in the document must map to at least one review unit. If a paragraph contains several separable legal propositions, create several units or one clearly bounded complex-issue unit.
7. Process review units in document order. For long documents, process batches of 3 to 6 review units at a time, but call the subagent once per review unit.
8. For each review unit, call `agent_legal-issue-precedent-checker` with exactly one focused issue or confined issue complex. Do not ask the agent to review the whole document in one call.
9. Parse the agent's JSON output and keep findings in document order.
10. After each batch, update an internal ledger of `pending`, `sent_to_agent`, `agent_done`, `comment_pending`, `comment_inserted`, and `comment_skipped` units. Then continue with the next pending batch.
11. Convert agent results into Word comments only where a material finding exists or where a verification note is useful under the user's instruction.
12. Add Word comments sequentially, one tool call at a time.
13. After all comment insertions, list comments with `word_comment_list` and verify the count.
14. Return a concise summary of coverage, comments inserted, skipped comments, and limitations.

## Mandatory delegation

The parent skill is responsible for orchestration, segmentation, anchoring, Word comment insertion, and verification.

The parent skill must delegate substantive legal research for each review unit to `agent_legal-issue-precedent-checker`, unless the agent is unavailable. If unavailable, report the limitation explicitly and do not imply that full precedent checking was completed.

If a call to `agent_legal-issue-precedent-checker` returns `subagent_required_tool_missing`, `unknown_tool`, `No task JSON input was provided`, or another configuration/input error, stop the review and report the exact configuration problem. Do not fall back to direct legal research in the parent skill.

## Agent call contract

The preferred subagent tool-call arguments are top-level fields:

```json
{
  "review_id": "LMPC-001",
  "unit": {
    "unit_id": "U-001",
    "anchor_text": "Exact text or shortest reliable excerpt from the document",
    "section_heading": "Heading or Nicht ersichtlich",
    "issue_type": "case_law | statute | regulation | procedural_rule | legal_test | burden_standard | remedy | limitation_exception | mixed_issue | omission_check",
    "jurisdiction_or_forum": "Jurisdiction, court, arbitral forum, or Nicht ersichtlich",
    "proposition_or_issue": "The focused legal statement or confined issue complex to verify",
    "authorities_mentioned": ["Authority names/citations from the document"],
    "document_context": "Nearby paragraph or compact context needed to understand the statement"
  },
  "research_scope": {
    "use_public_web": true,
    "use_local_knowledge": true,
    "use_legal_precedent_databases": true,
    "freshness_required": true,
    "negative_treatment_required": true,
    "check_missing_material_points": true,
    "output_language": "same language as the user request"
  }
}
```

Do not pass only a natural-language task sentence if the tool schema accepts structured arguments. If the tool schema exposes only a single `input` parameter, pass the same JSON object serialized as one JSON string in `input`; the string must begin with `{` and end with `}`.

Never send a subagent prompt that consists only of `Task:` without the actual issue content.

## Research requirements per unit

For every review unit, the delegated agent must check:

- whether the proposition is supported by current primary law;
- whether the cited authority says what the memo claims it says;
- whether the cited authority is still good law or has negative treatment, repeal, amendment, overruling, limitation, reversal, distinguishing, or contrary later authority;
- whether later law or precedent changes the conclusion;
- whether the memo omits material elements, exceptions, procedural prerequisites, burdens, standards, time limits, remedies, or contrary authority;
- whether the authority is binding, persuasive, obsolete, non-binding, or jurisdictionally mismatched;
- whether the wording overstates, understates, or mischaracterizes the law;
- whether any factual premise in the legal statement appears unsupported by the provided document context.

## Long-document batching and ledger

Before research, create a complete review-unit ledger. Use stable identifiers in document order: `U-001`, `U-002`, etc.

For each batch:

1. Select the next 3 to 6 units whose status is `pending`.
2. Call `agent_legal-issue-precedent-checker` once per selected unit.
3. Store each returned JSON object.
4. Mark failed configuration/input calls as `blocked` and stop the run.
5. Convert completed results into comment candidates.
6. Add comments sequentially.
7. Verify visible comments.
8. Continue with the next pending batch.

Do not stop merely because the first batch produced comments. Continue until there are no pending material review units or the host iteration limit makes continuation impossible.

## Commenting policy

Add comments only for useful review findings. The default is to comment on:

- incorrect legal propositions;
- outdated propositions;
- unsupported or weakly supported propositions;
- missing material law, exceptions, elements, contrary authority, or negative treatment;
- misquoted or overextended precedent;
- jurisdictional mismatch;
- important uncertainty or source gap that a lawyer must resolve.

Do not add comments merely to say that every sentence is correct unless the user explicitly requested exhaustive positive verification comments.

## Word comment style

Every comment must be concise, action-oriented, and source-grounded. Start each comment with one of:

- `[Critical]`
- `[High]`
- `[Medium]`
- `[Low]`
- `[Verified]` only when the user requested positive verification comments or the verification is strategically important.

A comment should usually contain status, short finding, source basis, and recommended action.

## Anchor rules

- Use the smallest reliable anchor span: usually the sentence containing the checked proposition.
- For a footnote/citation issue, anchor to the citation or the sentence that uses it.
- For an omitted issue, anchor to the closest related heading, issue sentence, or paragraph.
- If the exact anchor is not found, retry with a shorter exact phrase, citation, heading, or nearest related clause.
- If no reliable anchor exists, do not place a misleading comment. Record the finding as skipped and report it in the final summary.

## Sequencing rule for Word comments

Word comment tools are stateful editing tools. Therefore:

- never batch multiple `word_comment_add` calls in one model response;
- add one comment;
- wait for the tool result;
- then add the next comment;
- continue until all findings have been processed;
- finally verify with the comment-list tool.

## Finding format

Maintain each finding internally in this form:

```json
{
  "finding_id": "LMPC-F-001",
  "unit_id": "U-001",
  "severity": "Critical | High | Medium | Low | Verified | Info",
  "status": "incorrect | outdated | unsupported | incomplete | overbroad | jurisdiction_mismatch | negative_treatment | verified | uncertain",
  "anchor_text": "Exact proposed anchor",
  "issue": "What is wrong or what was verified",
  "supporting_sources": ["Source name/citation/date"],
  "recommended_comment": "Comment text to insert",
  "comment_status": "pending | inserted | skipped | not_possible",
  "skip_reason": null
}
```

## Final response

Return a concise summary in the user's language with:

- document reviewed;
- agent used: yes/no;
- number of review units isolated;
- number of units researched;
- number of material findings;
- number of comments inserted according to insertion calls;
- number of comments visible in verification;
- skipped comments and reasons;
- unprocessed review units, if any;
- important source gaps or limitations.

Do not reproduce the full research record unless the user asks for it.
