---
name: workspace-file-table-builder
description: Builds a structured Markdown table from many workspace files by delegating one file at a time to the workspace_file_row_worker agent, without writing any intermediate JSON state file.
allowed-tools:
  - workspace_get
  - workspace_inventory
  - workspace_write
  - workspace_extract_text
  - agent_workspace_file_row_worker
  - js_run
model: agentdefaultmodel
---

# Workspace File Table Builder Skill

Use this skill when the user asks to inspect, summarize, classify, extract, compare, or evaluate many workspace files and produce a Markdown table.

You are the orchestrator only. Do not read or reason over full file contents for table rows yourself unless strictly needed for emergency recovery.

For each selected file, delegate extraction to:

`agent_workspace_file_row_worker`

The row-worker agent returns exactly one compact row object or one compact error object.

## Core principle

This skill is a tool-loop workflow, not a progress-report workflow.

While any selected file is still pending, the only valid assistant response is the next required tool call. Do not tell the user what you will do next. Do it.

No intermediate JSON state file may be created, written, read, updated, or used.

## Critical worker-call contract

`agent_workspace_file_row_worker` accepts only:

- `task` (string, required)
- `context` (string, optional)

Therefore, when calling the worker, place the worker input into the `task` string as JSON text.

This JSON text is only the tool argument payload. It must not be written to a workspace file.

Use this exact shape inside the `task` string:

```json
{
  "file": {
    "path": "workspace-relative/path.ext",
    "name": "filename.ext"
  },
  "columns": ["Column 1", "Column 2"],
  "criteria": "Optional extraction criteria",
  "language": "German"
}
```

You may pass the original user request as the optional `context` string.

Do not call the worker with top-level arguments such as `file`, `columns`, `criteria`, or `language`.

## Absolute no-prose rule during execution

Normal prose is forbidden until every selected file has status `done`, `error`, or `skipped`.

This includes progress messages such as:

- "Ich habe den Skill geladen..."
- "Die Metadaten wurden erfasst..."
- "Nun werde ich die Dateien verarbeiten..."
- "Ich fahre jetzt fort..."
- "I will now process..."

If you are about to write any sentence containing future intent while pending files exist, stop and call the next required tool instead.

## Non-negotiable continuation rule

After every tool call, inspect the in-memory workflow state and continue with the next required tool call.

In particular:

1. After `skill_use`, call `workspace_get`.
2. After `workspace_get`, call `workspace_inventory`.
3. After `workspace_inventory`, build the complete in-memory workflow state.
4. If any file is pending, the next assistant response must be an `agent_workspace_file_row_worker` tool call for exactly one pending file.
5. After each worker call, update the matching in-memory file entry.
6. If any file is still pending, the next assistant response must be another `agent_workspace_file_row_worker` tool call for exactly one pending file.
7. Repeat until no pending files remain.
8. Only then finalize.
9. During finalization, create only the final Markdown output file with `workspace_write`.

Do not produce a normal prose response while any selected file still has status `pending`.

## In-memory workflow state

Maintain compact workflow state internally in the conversation/tool-loop context only.

Do not write this state to the workspace.

Use this logical schema internally:

```json
{
  "task": "",
  "columns": [],
  "criteria": "",
  "language": "German",
  "output_file": "workspace_file_table.md",
  "files": [
    {
      "path": "",
      "name": "",
      "status": "pending",
      "row": null,
      "error": null
    }
  ]
}
```

The schema above documents the internal structure only. It is not a file schema and must not be persisted as JSON.

## File selection rules

1. Call `workspace_get` to confirm workspace access.
2. If no readable workspace is connected, stop and explain that clearly.
3. Call `workspace_inventory` to list candidate files.
4. Exclude:
   - `workspace_file_table.md`
   - files beginning with `~$`
   - temporary files
   - hidden lock files
   - output files created by this skill
   - previous generated reports unless the user explicitly requested them
   - any intermediate state, cache, or scratch files created by previous runs
5. If the user specified exact files, use exactly those files.
6. If the user specified a folder, pattern, or file type, follow that scope.
7. Otherwise select all relevant non-excluded files.
8. If a file is not readable or unsupported, still include it in the in-memory state and let the worker return `error`; do not silently omit it unless it matches an exclusion rule.

## Column rules

If the user explicitly provided columns, use exactly those columns, preserving wording and order.

If the user requested filename plus summary only, use exactly:

- `Datei`
- `Zusammenfassung`

Otherwise use exactly:

- `Datei`
- `Dokumenttyp`
- `Hauptthema`
- `Kernaussagen`
- `Relevante Fristen/Zahlen`
- `Auffälligkeiten`
- `Kurzbewertung`

## Criteria construction

When the user asks for term occurrence and substantive statements, pass a precise `criteria` string to the worker.

Example for a requested term such as `Preisspanne`:

- Search for the exact word `Preisspanne`.
- Search for obvious grammatical variants and compounds only if relevant.
- In the occurrence column, answer `Ja` or `Nein` and include compact fundstelle(s) if present.
- In the substantive-statement column, state whether the document says anything content-related about the term, what it says, and where.
- If nothing substantive is apparent, write exactly `Nicht ersichtlich`.
- Do not infer substantive meaning merely from general pricing discussion unless it clearly relates to the requested term.

## Workflow

### Phase 1 — Initialize

1. Call `workspace_get`.
2. Call `workspace_inventory`.
3. Select relevant input files.
4. Determine the exact columns.
5. Determine extraction criteria.
6. Build the in-memory workflow state with every selected input file set to status `pending`.
7. Do not create an intermediate JSON file.
8. Do not produce prose.
9. Immediately continue with Phase 2 by calling the row-worker for the first pending file.

### Phase 2 — Process files via row-worker agent

1. Select exactly one pending file from the in-memory workflow state.
2. Call `agent_workspace_file_row_worker`.
3. Put the worker input JSON into the worker tool's `task` string.
4. Optionally pass the original user request as the worker `context`.
5. Validate the worker result minimally:
   - it must clearly refer to the requested file path;
   - `status` must be `done` or `error`;
   - if `status` is `done`, the returned row must contain exactly the requested columns.
6. Update the matching in-memory file entry:
   - `done` plus row on success;
   - `error` plus short error message on failure.
7. If any file is still `pending`, repeat Phase 2 immediately.
8. Do not emit progress prose between files.

## Worker failure handling

If `agent_workspace_file_row_worker` fails or returns invalid output:

1. Mark only that file as `error` in the in-memory workflow state.
2. Store a short error message.
3. Continue with the next pending file.
4. Do not retry the same file more than once unless a changed request can clearly fix it.
5. Never let one failed file stop the whole table.

## Emergency fallback

Use this fallback only if the row-worker tool is genuinely unavailable at runtime.

If `agent_workspace_file_row_worker` is not present in the actual tool registry, process one pending file at a time with `workspace_extract_text`, create the row directly, update the in-memory workflow state, and continue until no pending files remain. Keep the same no-prose rule while any file is pending.

Do not create a JSON file for fallback state.

## No empty table rule

Never write a final table where every data cell says only `Nicht ersichtlich` unless the worker or emergency fallback actually processed every file and returned that result.

If no file processing has completed, finalization is forbidden.

## Finalization

Only enter finalization when no `pending` files remain.

Steps:

1. Build the final table from stored in-memory row objects only.
2. Separately list files with `error` status.
3. Create a durable workspace output file using `workspace_write`.

Recommended output file:

`workspace_file_table.md`

The Markdown file must contain:

- a heading;
- the completed table;
- an `## Fehler` section if any file failed;
- no internal logs;
- no unnecessary raw extracted text;
- no serialized in-memory workflow state;
- no intermediate JSON content.

4. Final prose response must mention:
   - the output file path;
   - how many files were processed;
   - how many succeeded;
   - how many failed.

## Markdown table rules

- The table must contain exactly the selected columns.
- Use only stored row values from the in-memory workflow state.
- Escape `|` characters inside cell values as `\|`.
- Replace line breaks inside cell values with `<br>`.
- Keep every row compact.

## Recommended host-side guard

If the host detects a normal text response while the in-memory workflow state contains any file with status `pending`, the host should reject the text response and force the next required tool call.

The host should not rely on a workspace JSON file to detect pending work.

Repeating the same text-only prompt is not sufficient.
