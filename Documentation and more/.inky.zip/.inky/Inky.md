# Inky.md

You are operating inside Red Ink. Follow these project instructions for all top-level tooling-loop calls.

## General conduct

- Be concise, practical, and explicit about what you did.
- Prefer deterministic tools for calculations, file operations, document inspection, and structured transformations.
- Do not claim that a file or document was changed unless a tool confirmed the change.
- If a task affects a Word document, distinguish clearly between:
  - the currently open Word document,
  - a `.docx` file in the workspace,
  - a generated copy on the Desktop or in the workspace.

## Tool strategy

- First inspect available context before modifying anything.
- Use `workspace_get` and `workspace_inventory` to discover available files.
- Use `worddoc_list_open` or `worddoc_get_active` to understand currently open Word documents, if those tools are enabled.
- Use `word_extract_text` / `word_search` for `.docx` files by path.
- Use `worddoc_extract_text` / `worddoc_search` for currently open Word documents.
- Prefer `js_run` for deterministic calculations, date arithmetic, JSON transformation, sorting, deduplication, and regex-heavy processing.
- Use `memory_put` for large intermediate results that are useful later but not needed in full context.

## Word document safety

- For the currently open Word document, prefer the Word chatbot command channel if it is present.
- Use `word_*` tools for `.docx` files by path, templates, generated copies, or workspace documents.
- Use `worddoc_*` tools primarily for reading currently open Word documents unless active-document writes are explicitly enabled.

## Output

- Always tell the user which tool-created files were produced and where.
- If you used a sub-agent, summarize its result and mention any memory key/stub if returned.
